<?php
      // here require menu or navbar right
      $pageName = "اشعارات التطبيق";
      require "inc/menu.php";
    ?>

        <!-- Content wrapper -->
        <div class="content-wrapper">
          <!-- Content -->

          <div class="container-xxl flex-grow-1 container-p-y">
            <div class="row">
                <div class="col-lg-12 text-center mt-5">
                    <h3>اشعارات التطبيق</h3>
                </div>
            </div>  
          </div>
              <!-- end table data product -->
          </div>
          <!-- / Content -->

        <?php require "inc/footer.php"; ?>