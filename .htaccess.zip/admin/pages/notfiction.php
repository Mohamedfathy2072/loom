<?php
      // here require menu or navbar right
      $pageName = "السلات المتروكة";
      require "inc/menu.php";
    ?>

        <!-- Content wrapper -->
        <div class="content-wrapper">
          <!-- Content -->

          <div class="container-xxl flex-grow-1 container-p-y">
            <div class="row">
                <div class="col-lg-12 text-center mt-5 pt-5">
                    <h3>السلات متروكة</h3>
                    <form method="post">
                        <button type="submit" class="btn btn-danger">
                            ارسال تذاكر الي جميع
                        </button>
                    </form>
                </div>
            </div>  
          </div>
              <!-- end table data product -->
          </div>
          <!-- / Content -->

      <?php require "inc/footer.php"; ?>