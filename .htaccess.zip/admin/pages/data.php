<?php
      // here require menu or navbar right
      $pageName = "التقارير";
      require "inc/menu.php";
    ?>
        <!-- Content wrapper -->
        <div class="content-wrapper">
          <!-- Content -->

          <div class="container-xxl flex-grow-1 container-p-y">
            <div class="row">
                <div class="col-lg-12 text-center mt-5 pt-5">
                    <h3>قريبا</h3>
                    <a href="index.php" class="btn btn-dark">
                        رجوع للصفحة الرئيسية
                    </a>
                </div>
            </div>  
          </div>
              <!-- end table data product -->
          </div>
          <!-- / Content -->

          <?php require "inc/footer.php"; ?>